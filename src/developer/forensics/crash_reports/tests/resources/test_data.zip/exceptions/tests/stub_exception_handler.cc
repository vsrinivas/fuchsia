// Copyright 2020 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be found in the LICENSE file.

// Simple program that handles an exception by succeeding immediately.

#include <cstdlib>

int main(int argc, char** argv) { return EXIT_SUCCESS; }
